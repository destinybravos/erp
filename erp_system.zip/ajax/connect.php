<?php
$hostname = "localhost";
$db_username = "root";
$database = "erp";
$db_password = "";

$conn = new MySQLi($hostname, $db_username, $db_password, $database);


?>