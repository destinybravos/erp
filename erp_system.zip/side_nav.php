<link rel="stylesheet" href="css/side_nav.css">
<div class="side_nav">
    <div id="spacer">
    </div>

    <ul id="side_menu">
        <li class="list" style="background-color:black; text-align:center; padding:20px 0">
            <a href="#" style="padding:0;">
                <i class="fa fa-user" style="font-size:3rem;"></i>
                <br> <?php echo $fulname; ?>
                <br> <small> <em><?php echo $design; ?></em> </small>
            </a>
        </li>
        <li class="list">
            <a href="./">
                <i class="fa fa-tachometer-alt"></i> Dashboard
            </a>
        </li>
        <li class="list">
            <a href="#">
                <i class="fa fa-chevron-right tog" style="float:right; color:white; margin:5px 30px"></i>
                <i class="fa fa-money-bill"></i> Accounts
            </a>
            <ul class="sub_menu">
                <li class="list">
                    <a href="#">
                        <i class="fa fa-money-bill-wave"></i> Financial Planning
                    </a>
                </li>
                <li class="list">
                    <a href="budget.php">
                        <i class="fa fa-swatchbook"></i> budget Control
                    </a>
                </li>
                <li class="list">
                    <a href="funds.php">
                        <i class="fa fa-undo-alt"></i> Funds Control
                    </a>
                </li>
                <li class="list">
                    <a href="payments.php">
                        <i class="fa fa-money-check"></i> Payments
                    </a>
                </li>
            </ul>
        </li>
        <li class="list">
            <a href="#">
                <i class="fa fa-chevron-right tog" style="float:right; color:white; margin:5px 30px"></i>
                <i class="fa fa-capsules"></i> Materials
            </a>
            <ul class="sub_menu">
                <li class="list">
                    <a href="products.php">
                        <i class="fa fa-tablets"></i> Prouducts
                    </a>
                </li>
                <li class="list">
                    <a href="sales.php">
                        <i class="fa fa-object-group"></i> Make Sales
                    </a>
                </li>
                <li class="list">
                    <a href="reorder.php">
                        <i class="fa fa-money-bill-wave"></i> Orders Planning
                    </a>
                </li>
                <li class="list">
                    <a href="vendors.php">
                        <i class="fa fa-industry"></i> Vendors
                    </a>
                </li>
                <li class="list">
                    <a href="#">
                        <i class="fa fa-history"></i> Inventory
                    </a>
                </li>
            </ul>
        </li>
        <li class="list">
            <a href="#">
                <i class="fa fa-chevron-right tog" style="float:right; color:white; margin:5px 30px"></i>
                <i class="fa fa-user-cog"></i> Human Resource
            </a>
            <ul class="sub_menu">
                <li class="list">
                    <a href="#">
                        <i class="fa fa-money-bill-wave"></i> Employees
                    </a>
                </li>
                <li class="list">
                    <a href="performance.php">
                        <i class="fa fa-chart-line"></i> Performance
                    </a>
                </li>
            </ul>
        </li>
        <li class="list">
            <a href="#">
                <i class="fa fa-chevron-right tog" style="float:right; color:white; margin:5px 30px"></i>
                <i class="fa fa-users"></i> Customers
            </a>
            <ul class="sub_menu">
                <li class="list">
                    <a href="customers.php">
                        <i class="fa fa-user"></i> Customer Details
                    </a>
                </li>
                <li class="list">
                    <a href="transactions.php">
                        <i class="fa fa-history"></i> Transaction History
                    </a>
                </li>
                <li class="list">
                    <a href="#">
                        <i class="fa fa-thumbs-up"></i> Preference
                    </a>
                </li>
            </ul>
        </li>
        <li class="list">
            <a href="#">
                <i class="fa fa-chevron-right tog" style="float:right; color:white; margin:5px 30px"></i>
                <i class="fa fa-project-diagram"></i> Project Planning
            </a>
            <ul class="sub_menu">
                <li class="list">
                    <a href="#">
                        <i class="fab fa-monero"></i> Monitoring & Evaluation
                    </a>
                </li>
                <li class="list">
                    <a href="#">
                        <i class="fa fa-money-bill-wave"></i> Quality Management
                    </a>
                </li>
                <li class="list">
                    <a href="#">
                        <i class="fa fa-receipt"></i> Top Executives
                    </a>
                </li>
            </ul>
        </li>
    </ul>

</div>


<!-- Modal -->
<div class="modal fade" id="product_details" tabindex="-1" role="dialog" aria-labelledby="product_detailsLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="product_detailsLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="alert_modal_12" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body" id="" style="padding:30px auto; text-align:center;">
        <h1 id="alertMsgIcon"></h1>
        <span id="alertMsgSpan"></span>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="invoice" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body" id="invoiced" style="padding:0;">
        ...
      </div>
    </div>
  </div>
</div>


<!-- SALES Modal -->
<div class="modal fade" id="process_sales" tabindex="-1" role="dialog" aria-labelledby="detail_sale" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detail_sale">SALE ID 
                            <?php
                                if(isset($_SESSION['SALES_ID'])){
                                    echo ' : ' . $_SESSION['SALES_ID'];
                                }
                            ?>
                            </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <form method="post" name="frm_sale">
      <div class="modal-body">
        <div id="process_detail">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <td>
                            <strong>Customer Firstname: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control" type="text" name="fname" id="" required>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong>Customer Lastname: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control" type="text" name="lname" id="" required>
                                </div>
                            </div>  
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Customer Address: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control" type="text" name="address" id="" required>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong>Customer Phone Number: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control" type="tel" name="phone" id="" required>
                                </div>
                            </div>  
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <strong>Customer Email Address: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <input class="form-control" type="email" name="email" id="" required>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong>Number of Items: </strong> <br />
                            <div class="form-group">
                                <div class="input-group">
                                    <span id="total_qty"></span>
                                    <input type="hidden" name="total_qty">
                                </div>
                            </div>  
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2" style="text-align:right;">
                            <strong>Total Amount: </strong>
                            <span id="total_price"></span>
                            <input type="hidden" name="total_price">
                        </td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" name="sales_id">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary save_sales">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>